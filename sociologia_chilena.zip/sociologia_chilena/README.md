# sociologia_chilena
Repositorio caso de estudio para curso Ciencias Sociales Computacionales con Naim Bro

Tema: estudio temático de las publicaciones de sociología chilena los últimos 20 años y análisis de redes de colaboración de sus autores

Organizado según protocolo IPO
